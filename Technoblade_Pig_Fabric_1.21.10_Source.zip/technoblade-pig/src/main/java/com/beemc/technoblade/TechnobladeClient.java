package com.beemc.technoblade;

import net.fabricmc.api.ClientModInitializer;

public final class TechnobladeClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Appearance is applied by the client-side pig renderer mixin.
    }
}

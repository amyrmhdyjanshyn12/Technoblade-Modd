package com.beemc.technoblade.mixin;

import net.minecraft.client.render.entity.PigEntityRenderer;
import net.minecraft.entity.passive.PigEntity;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PigEntityRenderer.class)
public abstract class PigEntityRendererMixin {
    private static final Identifier TECHNOBLADE_TEXTURE =
            Identifier.of("technoblade", "textures/entity/technoblade_pig.png");

    @Inject(method = "getTexture", at = @At("HEAD"), cancellable = true)
    private void technoblade$specialTexture(PigEntity pig, CallbackInfoReturnable<Identifier> cir) {
        if (pig.hasCustomName() && "Technoblade".equalsIgnoreCase(pig.getCustomName().getString())) {
            cir.setReturnValue(TECHNOBLADE_TEXTURE);
        }
    }
}
